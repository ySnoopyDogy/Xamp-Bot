
class SlashCommand {
  constructor(client, options) {
    this.client = client;
    this.config = options
  }

  run() { }
}

module.exports = SlashCommand